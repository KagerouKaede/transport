// export const demo = 'https://a.amap.com/jsapi_demos/static/demo-center/js/demoutils.js';
// export const securityCode = "66a648ae3df1a14790ef971d2116deac";

const base = 'https://webapi.amap.com/maps';
const version = '2.0';
const key = 'a377af7b97013dde174c4f91b7e823c9'
const plugin =
'AMap.Driving,' +
'AMap.ToolBar,' +
'AMap.Scale,' +
'AMap.ControlBar';

const ApiSrc = base +
'?v=' + version +
'&key=' + key +
'&plugin=' + plugin;
export { ApiSrc };